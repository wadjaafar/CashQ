package net.soluspay.cashq.utils;


public class Security {



}
