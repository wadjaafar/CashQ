package net.soluspay.cashq.utils;

public class Globals {
    public static String serviceName;
    public static String service;
}
